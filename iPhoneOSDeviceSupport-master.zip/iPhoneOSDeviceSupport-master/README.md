# iPhoneOSDeviceSupport
Xcode iPhoneOS DeviceSupport files (13.4++)

最新上传 13.4


Device Support files for Xcode, from iOS 6, up to 13.2.

How to:

Download version you need listed above;
Unzip it;
Close Xcode;
Copy and paste unziped folder by path: "/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/DeviceSupport/"
